
package com.example.android.tourguide;


/**
 * Created by sharma on 22-03-2017.
 */

public class Location {

    private int mName;
    private int mRating;
    private int mAddress;
    private int mImageResourceId;

    public Location(int name, int rating, int address, int imageresource) {
        mImageResourceId = imageresource;
        mName = name;
        mRating = rating;
        mAddress = address;
    }

    public int getName() {
        return mName;
    }

    public int getRating() {
        return mRating;
    }

    public int getAddress() {
        return mAddress;
    }

    public int getImageResource() {
        return mImageResourceId;
    }
}
