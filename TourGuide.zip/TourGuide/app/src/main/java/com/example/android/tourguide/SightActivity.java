package com.example.android.tourguide;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

public class SightActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word_list);

        ArrayList<Location> locations = new ArrayList<Location>();
        locations.add(new Location(R.string.sightName1, R.string.sightRating1, R.string.sightPlace1, R.drawable.fjallianwala));
        locations.add(new Location(R.string.sightName2, R.string.sightRating2, R.string.sightPlace2, R.drawable.maharaja_ranjit_singh));
        locations.add(new Location(R.string.sightName3, R.string.sightRating3, R.string.sightPlace3, R.drawable.gandhigate));
        locations.add(new Location(R.string.sightName4, R.string.sightRating4, R.string.sightPlace4, R.drawable.suncity));
        locations.add(new Location(R.string.sightName5, R.string.sightRating5, R.string.sightPlace5, R.drawable.companybagh));
        locations.add(new Location(R.string.sightName6, R.string.sightRating6, R.string.sightPlace6, R.drawable.maharaja_ranjit_singh));

        LocationAdapter adapter = new LocationAdapter(this, locations);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}
