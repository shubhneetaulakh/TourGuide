package com.example.android.tourguide;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

public class ShoppingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word_list);

        ArrayList<Location> locations = new ArrayList<Location>();
        locations.add(new Location(R.string.shoppingName1, R.string.shoppingRating1, R.string.shoppingPlace1, R.drawable.queensinstyle));
        locations.add(new Location(R.string.shoppingName2, R.string.shoppingRating2, R.string.shoppingPlace2, R.drawable.focalpoint));
        locations.add(new Location(R.string.shoppingName3, R.string.shoppingRating3, R.string.shoppingPlace3, R.drawable.gurubazaarr));
        locations.add(new Location(R.string.shoppingName4, R.string.shoppingRating4, R.string.shoppingPlace4, R.drawable.humanbeingalphaone2));
        locations.add(new Location(R.string.shoppingName5, R.string.shoppingRating5, R.string.shoppingPlace5, R.drawable.kapdabazaar));
        locations.add(new Location(R.string.shoppingName6, R.string.shoppingRating6, R.string.shoppingPlace6, R.drawable.standardmaxjpg));
        locations.add(new Location(R.string.shoppingName7, R.string.shoppingRating7, R.string.shoppingPlace7, R.drawable.triliumcarton));

        LocationAdapter adapter = new LocationAdapter(this, locations);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}
