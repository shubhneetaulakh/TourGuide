package com.example.android.tourguide;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class RestaurantActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word_list);

        ArrayList<Location> locations = new ArrayList<Location>();
        locations.add(new Location(R.string.restaurantName1, R.string.restaurantRating1, R.string.restaurantPlace1, R.drawable.eldorado));
        locations.add(new Location(R.string.restaurantName2, R.string.restaurantRating2, R.string.restaurantPlace2, R.drawable.charcoal));
        locations.add(new Location(R.string.restaurantName3, R.string.restaurantRating3, R.string.restaurantPlace3, R.drawable.fuelstop));
        locations.add(new Location(R.string.restaurantName4, R.string.restaurantRating4, R.string.restaurantPlace4, R.drawable.sandella));
        locations.add(new Location(R.string.restaurantName5, R.string.restaurantRating5, R.string.restaurantPlace5, R.drawable.goldentulip));
        locations.add(new Location(R.string.restaurantName6, R.string.restaurantRating6, R.string.restaurantPlace6, R.drawable.bakesbeans));

        LocationAdapter adapter = new LocationAdapter(this, locations);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}
