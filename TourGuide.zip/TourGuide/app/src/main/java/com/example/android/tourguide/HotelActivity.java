package com.example.android.tourguide;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class HotelActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word_list);

        ArrayList<Location> locations = new ArrayList<Location>();
        locations.add(new Location(R.string.hotelName1, R.string.hotelRating1, R.string.hotelPlace1, R.drawable.holidayinnamritsar));
        locations.add(new Location(R.string.hotelName2, R.string.hotelRating2, R.string.hotelPlace2, R.drawable.hyattamritsar));
        locations.add(new Location(R.string.hotelName3, R.string.hotelRating3, R.string.hotelPlace3, R.drawable.tajswarna));
        locations.add(new Location(R.string.hotelName4, R.string.hotelRating4, R.string.hotelPlace4, R.drawable.radissonbluamritsar));
        locations.add(new Location(R.string.hotelName5, R.string.hotelRating5, R.string.hotelPlace5, R.drawable.ramada));
        locations.add(new Location(R.string.hotelName6, R.string.hotelRating6, R.string.hotelPlace6, R.drawable.regentaa));


        LocationAdapter adapter = new LocationAdapter(this, locations);
        ListView listView = (ListView) findViewById(R.id.list);

        listView.setAdapter(adapter);

    }
}
