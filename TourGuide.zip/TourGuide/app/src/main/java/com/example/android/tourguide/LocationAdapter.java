package com.example.android.tourguide;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by sharma on 22-03-2017.
 */

public class LocationAdapter extends ArrayAdapter<Location> {

    public LocationAdapter(Activity context, ArrayList<Location> words) {
        super(context, 0, words);
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        // Check if the existing view is being reused, otherwise inflate the view
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_item, parent, false);
        }
        // Get the {@link AndroidFlavor} object located at this position in the list
        Location currentWord = getItem(position);

        // Find the TextView in the list_item.xml layout with the ID version_name
        TextView place_name = (TextView) listItemView.findViewById(R.id.place_name);
        place_name.setText(getContext().getString(currentWord.getName()));

        TextView rating = (TextView) listItemView.findViewById(R.id.rating);
        rating.setText(getContext().getString(currentWord.getRating()));

        TextView address = (TextView) listItemView.findViewById(R.id.address);
        address.setText(getContext().getString(currentWord.getAddress()));

        ImageView iconView = (ImageView) listItemView.findViewById(R.id.icon_view);
        iconView.setImageResource(currentWord.getImageResource());

        return listItemView;
    }
}

