package com.example.android.tourguide;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private ImageView hotel;
    private ImageView restaurant;
    private ImageView shopping;
    private ImageView sight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        hotel = (ImageView) findViewById(R.id.hotel);
        hotel.setOnClickListener(this);

        restaurant = (ImageView) findViewById(R.id.restaurant);
        restaurant.setOnClickListener(this);

        shopping = (ImageView) findViewById(R.id.shopping);
        shopping.setOnClickListener(this);

        sight = (ImageView) findViewById(R.id.sight);
        sight.setOnClickListener(this);

    }

    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.hotel:
                Intent hotelIntent = new Intent(MainActivity.this, HotelActivity.class);
                startActivity(hotelIntent);
                break;

            case R.id.restaurant:
                Intent restaurantIntent = new Intent(MainActivity.this, RestaurantActivity.class);
                startActivity(restaurantIntent);
                break;

            case R.id.shopping:
                Intent shoppingIntent = new Intent(MainActivity.this, ShoppingActivity.class);
                startActivity(shoppingIntent);
                break;

            case R.id.sight:
                Intent sightIntent = new Intent(MainActivity.this, SightActivity.class);
                startActivity(sightIntent);
                break;
        }
    }
}
